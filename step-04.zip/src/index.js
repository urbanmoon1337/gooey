import './styles.css'
import Scene from './Scene'

window.scene = new Scene()
